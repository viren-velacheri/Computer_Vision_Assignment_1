% This function carves out a certain number of vertical seams from image.
% Input is color image and the number of pixels or seams to be removed
% while the output is this new image with the vertical seams carved out.
function removedVerticalSeams = removeVertical(im, numPixels)
% Simple for loop that goes through and finds each vertical seam, image
% is carved out and updated one by one and that is about it. Uint8 
% conversion done at end.
for j = 1: numPixels
    vertOptimalSeam = optimal_vertical_seam(im);
    for i = 1: length(vertOptimalSeam)
        im(i, vertOptimalSeam(i):end-1, :) = im(i,vertOptimalSeam(i) + 1:end, :);
    end
    im = im(:, 1:end - 1, :);
end
removedVerticalSeams = uint8(im);

    