% This function carves out a certain number of horizontal seams from image.
% Input is color image and the number of pixels or seams to be removed
% while the output is this new image with the horizontal seams carved out.
function removedHorizontalSeams = removeHorizontal(im, numPixels)
% Simple for loop that goes through and finds each horizontal seam, image
% is carved out and updated one by one and that is about it. Uint8 
% conversion done at end.
for j = 1: numPixels
    horizontalOptimalSeam = optimal_horizontal_seam(im);
    for i = 1: length(horizontalOptimalSeam)
        im(horizontalOptimalSeam(i):end - 1, i, :) = im(horizontalOptimalSeam(i) + 1:end,i,:);
    end
    im = im(1:end-1,:, :);
end
removedHorizontalSeams = uint8(im);
    