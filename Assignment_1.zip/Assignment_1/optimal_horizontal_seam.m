% This function finds the optimal seam to remove in horizontal direction
% based off inputted color image. The seam to remove is returned at the 
% end as output. 
function horizontalSeam = optimal_horizontal_seam(I)
% Get energy image, then map afterwards.
% Get rows and columns based off it.
energyImage = energyFunc(I); 
horizontalEnergyMap = horizontal_energy_map(energyImage);
[rows, cols] = size(horizontalEnergyMap);
horizontalSeam = zeros(1, cols);
[~, index] = min(horizontalEnergyMap(:, cols));
horizontalSeam(cols) = index;

% This is the dynamic programming approach where we use our computed 
% cumulative minimum energy map in horizontal direction to sort of 
% backtrack and get all pixels with lowest energy in map.
for i = cols - 1: -1: 1
    if index == cols
        [~, k] = min([horizontalEnergyMap(rows - 1, i), horizontalEnergyMap(rows, i)]);
    elseif index == 1
        [~, k] = min([horizontalEnergyMap(1, i), horizontalEnergyMap(2, i)]);
        k = k + 1;
    else 
        [~, k] = min([horizontalEnergyMap(horizontalSeam(i + 1) - 1, i), horizontalEnergyMap(horizontalSeam(i + 1), i), horizontalEnergyMap(horizontalSeam(i + 1) + 1, i)]);
    end
    if k == 3
        index = horizontalSeam(i + 1) + 1;
    elseif k == 2
        index = horizontalSeam(i + 1);
    elseif k == 1
        index = horizontalSeam(i + 1) - 1;
    end
    horizontalSeam(i) = index;
end
end



