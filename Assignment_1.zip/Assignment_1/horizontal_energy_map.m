% This function takes in our matrix with energies of all pixels in image
% and returns back the cumulative minimum energy map in horizontal direction.
function horizontalEnergyMap = horizontal_energy_map(energyImage)
[rows, cols] = size(energyImage);
M = zeros(rows, cols);
M(:,1) = energyImage(:, 1);
% Go from left to right in image, just iterate through and go in whichever
% non horizontal direction the pixel with least energy is. 
for j = 2: cols
    for i = 2: rows - 1
        M(i, j) = energyImage(i,j) + min([M(i - 1, j - 1), M(i, j - 1), M(i + 1, j - 1)]);
    end
    M(1, j) = energyImage(1, j) + min([M(1, j - 1), M(2, j - 1)]);
    M(rows, j) = energyImage(rows, j) + min([M(rows - 1, j - 1), M(rows, j - 1)]);
end
horizontalEnergyMap = M;
end