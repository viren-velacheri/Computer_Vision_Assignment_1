% Function that I used for showing removed horizontal seams in original
% image. Input is color image and number of pixels or seams to be removed.
% Output is displayed the removed seams in original image and returning
% new image with seams removed as well.
function removedHorizontalSeams = show_horizontal_seams(im, numPixels)
originalImage = im;
% Simple loop that goes through and finds optimal horizontal seam
%  and image is updated accordingly so next optimal one can be found.
%  As we are going along, seam is set accordingly to red in original image.
for j = 1: numPixels
    horizontalOptimalSeam = optimal_horizontal_seam(im);
    for i = 1: length(horizontalOptimalSeam)
        im(horizontalOptimalSeam(i):end - 1, i, :) = im(horizontalOptimalSeam(i) + 1:end,i,:);
        originalImage(horizontalOptimalSeam(i), i, 1) = 255;
        originalImage(horizontalOptimalSeam(i), i, 2) = 0;
        originalImage(horizontalOptimalSeam(i), i, 3) = 0;
    end
    im = im(1:end-1,:, :);
end
imshow(originalImage);
removedHorizontalSeams = uint8(im);

    