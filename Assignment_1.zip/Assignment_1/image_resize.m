% This is the default reduce size function used pretty much. Inputs are
% the color image, dimension, and the number of pixels to remove
% in respective dimension.
function reducedImage = image_resize(I, dimension, numPixels)
[rows, cols, numColorChannels] = size(I);
% If width, subtract from number of columns. Otherwise, just assume
%  it is from Height. Like for display Seam, error checking not done
%  as I thought it unnecessary. 
if strcmp(dimension, 'WIDTH')
    newCols = cols - numPixels;
    reducedImage = imresize(I, [rows, newCols]);
else 
    newRows = rows - numPixels;
    reducedImage = imresize(I, [newRows, cols]);
end
end
