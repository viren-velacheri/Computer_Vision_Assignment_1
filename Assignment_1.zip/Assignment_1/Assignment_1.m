% Assignment 1
% Name: Viren Velacheri, EID: vv6898
% Slip days: 2

% The below are the pictures I used to display and then the original UT
% image is displayed along with the image after vertical seam carving where
% 100 vertical seams are removed.
picture1 = 'ut.jpg';
picture2 = 'river.jpg';
picture3 = 'antelope.png';
picture4 = 'island.png';
picture5 = 'castle.jpg';
figure("name", "Vertical Seams Removal Example","NumberTitle", "off");
ut_image = imread(picture1);
river_image = imread(picture2);
removeVerticalImage = removeVertical(ut_image, 100);
subplot(2,1,1);
imshow(ut_image);
title("Original UT Image");
subplot(2,1,2);
imshow(removeVerticalImage);
title("UT Image after Removal of Vertical Seams");

% Shows the river image along with the image of it after 100 horizontal
% seams are carved out.
figure("name", "Horizontal Seams Removal Example","NumberTitle", "off");
removeHorizontalImage = removeHorizontal(river_image, 100);
subplot(1, 2, 1);
imshow(river_image)
title("Original River Image");
subplot(1, 2, 2);
imshow(removeHorizontalImage);
title("River Image after Removal of Horizontal Seams");

% Energy function output for ut image.
figure("name", "Energy Function Output","NumberTitle", "off");
energyImage = energyFunc(ut_image);
subplot(1, 1, 1);
imagesc(energyImage);
title("Energy Function Output for UT Image");

% The Cumulative Minimum Energy Map in Vertical direction for UT image.
figure("name", "Vertical Energy Map","NumberTitle", "off");
verticalEnergyMap = vertical_energy_map(energyImage);
subplot(1, 1, 1);
imagesc(verticalEnergyMap);
title("Vertical Energy Map for UT Image");

% The Cumulative Minimum Energy Map in Horizontal direction for UT image.
figure("name", "Horizontal Energy Map","NumberTitle", "off");
horizontalEnergyMap = horizontal_energy_map(energyImage);
subplot(1, 1, 1);
imagesc(horizontalEnergyMap);
title("Horizontal Energy Map for UT Image");

% Original image of UT along with those show the Optimal Vertical and 
% Horizontal Seams are shown.
figure("name", "Original Image with Optimal Vertical and Horizonal Seams","NumberTitle", "off");
subplot(1, 3, 1);
imshow(ut_image);
title("Original UT Image");
horizontalSeam = optimal_horizontal_seam(ut_image);
subplot(1, 3, 2);
displaySeam(ut_image, horizontalSeam, 'HORIZONTAL');
title("Original UT Image with First Selected Horizontal Seam");
verticalSeam = optimal_vertical_seam(ut_image);
subplot(1, 3, 3);
displaySeam(ut_image, verticalSeam, 'VERTICAL');
title("Original UT Image with First Selected Vertical Seam");

% My First chosen image (Antelope) and its result are here. 
figure("name", "Antelope Image results","NumberTitle", "off");
antelope_image = imread(picture3);
subplot(2, 2, 1);
imshow(antelope_image);
title("240 by 318 Original Antelope Image");
systemResizedImage = removeVertical(antelope_image, 100);
subplot(2, 2, 3);
imshow(systemResizedImage);
title("240 by 218 Antelope Image with Vertical Seams Removed");
defaultResizedImage = image_resize(antelope_image, 'WIDTH', 100);
subplot(2, 2, 4);
imshow(defaultResizedImage);
title("240 by 218 Antelope Image with Baseline Resizing");
subplot(2, 2, 2);
show_vertical_seams(antelope_image, 100);
title("240 by 318 Antelope Image with Removals");

% My Second chosen image (Island) and its results are here.
figure("name", "Island Image results","NumberTitle", "off");
island_image = imread(picture4);
subplot(1, 4, 1);
imshow(island_image);
title("231 by 347 Original Island Image");
systemResizedImage = removeHorizontal(island_image, 100);
subplot(1, 4, 2);
imshow(systemResizedImage);
title("131 by 347 System Resized Island Image");
defaultResizedImage = image_resize(island_image, 'HEIGHT', 100);
subplot(1, 4, 3);
imshow(defaultResizedImage);
title("131 by 347 Baseline Resized Island Image");
subplot(1, 4, 4);
show_horizontal_seams(island_image, 100);
title("231 by 347 Island Image with Removals");

% My Third chosen image (Castle) and its results are here.
figure("name", "Castle Image Results","NumberTitle", "off");
castle_image = imread(picture5);
subplot(2, 2, 1);
imshow(castle_image);
title("813 by 1200 Castle Image");
systemResizedImage = removeVertical(castle_image, 400);
subplot(2, 2, 3);
imshow(systemResizedImage);
title("813 by 800 System Resized Castle Image");
defaultResizedImage = image_resize(castle_image, 'WIDTH', 400);
subplot(2, 2, 4);
imshow(defaultResizedImage);
title("813 by 800 Baseline Resized Castle Image");
subplot(2, 2, 2);
show_vertical_seams(castle_image, 400);
title("813 by 1200 Castle Image with Vertical Removals");