% This function shows the vertical seams removed in original image. Inputs
% are the color image and the number seams or pixels to be removed. Output
% is the image with these removed seams is displayed and new image is 
% returned as well.
function removedVerticalSeams = show_vertical_seams(im, numPixels)
originalImage = im;
% Simple for loop that goes through and finds each vertical optimal seam
% and goes through its entries to remove and this is diaplyed in original
% image before iterating to next cycle. 
for j = 1: numPixels
    vertOptimalSeam = optimal_vertical_seam(im);
    for i = 1: length(vertOptimalSeam)
        im(i, vertOptimalSeam(i):end-1, :) = im(i,vertOptimalSeam(i) + 1:end, :);
            originalImage(i, vertOptimalSeam(i), 1) = 255;
            originalImage(i, vertOptimalSeam(i), 2) = 0;
            originalImage(i, vertOptimalSeam(i), 3) = 0;
    end
    im = im(:, 1:end - 1, :);
end
imshow(originalImage);
removedVerticalSeams = uint8(im);

    