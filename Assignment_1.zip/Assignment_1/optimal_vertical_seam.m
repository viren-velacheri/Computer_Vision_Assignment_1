% This function finds the optimal seam to remove in vertical direction
% based off inputted color image. The seam to remove is returned at the 
% end as output. 
function vertSeam = optimal_vertical_seam(I)
% Get energy image, then map afterwards.
% Get rows and columns based off it.
energyImage = energyFunc(I);
verticalEnergyMap = vertical_energy_map(energyImage);
[rows, cols] = size(verticalEnergyMap);
vertSeam = zeros(rows, 1);
[~, index] = min(verticalEnergyMap(rows, :));
vertSeam(rows) = index;
% This is the dynamic programming approach where we use our computed 
% cumulative minimum energy map in vertical direction to sort of 
% backtrack and get all pixels with lowest energy in map.
for i = rows - 1: -1: 1
    if index == cols
        [~, k] = min([verticalEnergyMap(i, cols - 1), verticalEnergyMap(i, cols)]);
    elseif index == 1
        [~, k] = min([verticalEnergyMap(i, 1), verticalEnergyMap(i, 2)]);
        k = k + 1;
    else 
        [~, k] = min([verticalEnergyMap(i, vertSeam(i + 1) - 1), verticalEnergyMap(i, vertSeam(i + 1)), verticalEnergyMap(i, vertSeam(i + 1) + 1)]);
    end
    if k == 3
        index = vertSeam(i + 1) + 1;
    elseif k == 2
        index = vertSeam(i + 1);
    elseif k == 1
        index = vertSeam(i + 1) - 1;
    end
    vertSeam(i) = index;
end
end



