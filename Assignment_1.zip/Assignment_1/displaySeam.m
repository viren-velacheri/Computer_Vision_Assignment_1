% This function displays the selected seam in image. Inputs are the color
% image, the seam, and type of seam (Vertical or not). Output is image 
% with this displayed seam.
function imageWithSeam = displaySeam(I, seam, dimension)
[rows, cols, ~] = size(I);
% Assuming that if not Vertical it is horizontal
% Could have had it where it would take either Vertical or horizontal
% and any other inputs woud return an error but decided not to do that
% error checking. Pretty straightforward what I do. Selected seam is 
% displayed in red and in the respective direction.
if strcmp(dimension, 'VERTICAL')
    for i = 1:rows
        I(i, seam(i), 1) = 255;
        I(i, seam(i), 2) = 0;
        I(i, seam(i), 3) = 0;
    end
else 
    for i = 1:cols
        I(seam(i), i, 1) = 255;
        I(seam(i), i, 2) = 0;
        I(seam(i), i, 3) = 0;
    end
end
imageWithSeam = I;
imshow(imageWithSeam);
end
