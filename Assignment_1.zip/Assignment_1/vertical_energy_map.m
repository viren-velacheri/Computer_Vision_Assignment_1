% This function takes in our matrix with energies of all pixels in image
% and returns back the cumulative minimum energy map in vertical direction.
function verticalEnergyMap = vertical_energy_map(energyImage)
[rows, cols] = size(energyImage);
M = zeros(rows, cols);
M(1,:) = energyImage(1, :);
% Go from left to right in image, just iterate through and go in whichever
% non horizontal direction the pixel with least energy is. 
for i = 2: rows
    for j = 2: cols - 1
        M(i, j) = energyImage(i,j) + min([M(i - 1, j - 1), M(i - 1, j), M(i - 1, j + 1)]);
    end
    M(i, 1) = energyImage(i, 1) + min([M(i - 1, 1), M(i - 1, 2)]);
    M(i, cols) = energyImage(i, cols) + min([M(i - 1, cols), M(i - 1, cols - 1)]);
end
verticalEnergyMap = M;
end