% The below function gets energies for all pixel values in input I or the
% color image. Output is this energy image.
function energies = energyFunc(I)
% The below gauss filter I just used to see if it would make a difference
% Otherwise, before I didn't use any such smoothing or filter before hand
% to reduce noise. 
energies = imgaussfilt(I,2); 
energies = rgb2gray(energies);
energies = im2double(energies);
% Used sobel as it seemed like a common and popular filter that was used
% for getting gradients at each pixel within image.
x_filter = fspecial('sobel');
y_filter = fspecial('sobel');
y_filter = y_filter';
x_gradient = imfilter(energies, x_filter);
y_gradient = imfilter(energies, y_filter);
energies = zeros(size(energies, 1), size(energies, 2));

% Looped through to set values. I tried without looping and it wasn't 
% working for some reason so just stuck to this.
for y = 1:size(energies, 1)
    for x = 1:size(energies, 2)
        y_mag = y_gradient(y, x);
        x_mag = x_gradient(y, x);
        energies(y, x) = sqrt(y_mag.^2 + x_mag.^2);
        % The below line I have commented out is what I used originally
        % for calculating energies at pixels.
        % energies(y,x) = abs(y_mag) + abs(x_mag);
    end
end
end

